import React from 'react';

const Home = () => {
  return (
    <div style={{ maxWidth: '600px', margin: 'auto', padding: '50px' }}>
      <h1>MainPage</h1>
      <p>로그인 성공</p>
    </div>
  );
};

export default Home;
