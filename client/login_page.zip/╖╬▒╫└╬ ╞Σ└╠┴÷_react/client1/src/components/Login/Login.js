import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css'; // CSS 파일을 import

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate(); // useNavigate 훅을 사용하여 페이지 이동

  // 하드코딩된 사용자 자격 증명
  const hardcodedEmail = 'user@example.com';
  const hardcodedPassword = 'password123';

  const handleEmailChange = (e) => setEmail(e.target.value);
  const handlePasswordChange = (e) => setPassword(e.target.value);

  const validateEmail = (email) => {
    return /\S+@\S+\.\S+/.test(email);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    // 입력 검증
    if (!validateEmail(email)) {
      setError('유효한 이메일을 입력하세요.');
      return;
    }

    if (password.length < 6) {
      setError('비밀번호는 최소 6자리여야 합니다.');
      return;
    }

    setLoading(true);

    // 하드코딩된 자격 증명과 비교
    setTimeout(() => {
      if (validateEmail(email) && password.length >= 6) {
        navigate('/home'); // 로그인 성공 시 메인 페이지로 리다이렉트
      } else {
        setError('잘못된 이메일 또는 비밀번호');
      }
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="main-container">
      <div className="login-page-background"></div>
      <div className="logo"></div>
      <form onSubmit={handleSubmit}>
        <div className="id-input">아이디</div>
        <div className="id-icon">
          <div className="group"></div>
        </div>
        <input
          type="email"
          value={email}
          onChange={handleEmailChange}
          className="id-input-box"
        />
        <div className="password">비밀번호</div>
        <div className="vector-1"></div>
        <input
          type="password"
          value={password}
          onChange={handlePasswordChange}
          className="password-input"
        />
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <button type="submit" className="login-box" disabled={loading}>
          <div className="login">{loading ? 'Logging in...' : 'Login'}</div>
        </button>
      </form>
      <div className="triangle-right">
        <div className="vector"></div>
      </div>
    </div>
  );
};

export default Login;
